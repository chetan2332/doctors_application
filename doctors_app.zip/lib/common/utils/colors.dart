import 'package:flutter/animation.dart';

const backgroundColor = Color.fromARGB(255, 239, 239, 239);
const greenColor = Color.fromARGB(255, 53, 118, 39);
